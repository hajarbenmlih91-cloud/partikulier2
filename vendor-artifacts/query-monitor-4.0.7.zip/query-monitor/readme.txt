# Query Monitor

Contributors: johnbillion
Tags: debug, debug-bar, development, performance, query monitor
Tested up to: 7.0
Stable tag: 4.0.7
License: GPL v2 or later
Donate link: https://github.com/sponsors/johnbillion

Query Monitor is the developer tools panel for WordPress and WooCommerce.

## Description

Query Monitor is the developer tools panel for WordPress and WooCommerce. It enables debugging of database queries, PHP errors, hooks and actions, block editor blocks, enqueued scripts and stylesheets, HTTP API calls, and more.

It includes some advanced features such as debugging of Ajax calls, REST API calls, user capability checks, and full support for block themes and full site editing. It includes the ability to narrow down much of its output by plugin or theme, allowing you to quickly determine poorly performing plugins, themes, or functions.

Query Monitor focuses heavily on presenting its information in a useful manner, for example by showing aggregate database queries grouped by the plugins, themes, or functions that are responsible for them. It adds an admin toolbar menu showing an overview of the current page, with complete debugging information shown in panels once you select a menu item.

Query Monitor supports versions of WordPress up to three years old, and PHP version 7.4 or higher.

For complete information, please see [the Query Monitor website](https://querymonitor.com/).

Here's an overview of what's shown for each page load:

* Database queries, including notifications for slow, duplicate, or erroneous queries. Allows filtering by query type (`SELECT`, `UPDATE`, `DELETE`, etc), responsible component (plugin, theme, WordPress core), and calling function, and provides separate aggregate views for each.
* The template filename, the complete template hierarchy, and names of all template parts that were loaded or not loaded (for block themes and classic themes).
* PHP errors presented nicely along with their responsible component and call stack, and a visible warning in the admin toolbar.
* Usage of "Doing it Wrong" or "Deprecated" functionality in the code on your site.
* Blocks and associated properties within post content and within full site editing (FSE).
* Matched rewrite rules, associated query strings, and query vars.
* Enqueued scripts and stylesheets, along with their dependencies, dependents, and alerts for broken dependencies.
* Language settings and loaded translation files (MO files and JSON files) for each text domain.
* HTTP API requests, with response code, responsible component, and time taken, with alerts for failed or erroneous requests.
* User capability checks, along with the result and any parameters passed to the capability check.
* Environment information, including detailed information about PHP, the database, WordPress, and the web server.
* The values of all WordPress conditional functions such as `is_single()`, `is_home()`, etc.
* Transients that were updated.
* Usage of `switch_to_blog()` and `restore_current_blog()` on Multisite installations.

In addition:

* Whenever a redirect occurs, Query Monitor adds an HTTP header containing the call stack, so you can use your favourite HTTP inspector or browser developer tools to trace what triggered the redirect.
* The response from any jQuery-initiated Ajax request on the page will contain various debugging information in its headers. PHP errors also get output to the browser's developer console.
* The response from an authenticated WordPress REST API request will contain an overview of performance information and PHP errors in its headers, as long as the authenticated user has permission to view Query Monitor's output. An [an enveloped REST API request](https://developer.wordpress.org/rest-api/using-the-rest-api/global-parameters/#_envelope) will include even more debugging information in the `qm` property of the response.

By default, Query Monitor's output is only shown to Administrators on single-site installations, and Super Admins on Multisite installations.

In addition to this, you can set an authentication cookie which allows you to view Query Monitor output when you're not logged in (or if you're logged in as a non-Administrator). See the Settings panel for details.

### Browser extension

Query Monitor is also available as an optional browser dev tools extension. This is an alternative to using the in-page panel that gets output into the admin toolbar.

Using the browser extension has some advantages over the in-page panel:

* The Query Monitor panel doesn't take up space within the page you are inspecting
* The panel can be resized, undocked, and moved around like any other developer tools panel

[Information about the Query Monitor browser extension can be found here](https://querymonitor.com/wordpress-debugging/browser-extension/).

### Other Plugins

I maintain several other plugins for developers. Check them out:

* [User Switching](https://wordpress.org/plugins/user-switching/) provides instant switching between user accounts in WordPress.
* [WP Crontrol](https://wordpress.org/plugins/wp-crontrol/) lets you view and control what's happening in the WP-Cron system

### Thanks

The time that I spend maintaining this plugin and others is in part sponsored by:

* [Automattic](https://automattic.com/)
* [ServMask](https://servmask.com/)
* [WP Staging](https://wp-staging.com/)
* [All my kind sponsors on GitHub](https://github.com/sponsors/johnbillion)

### Privacy Statement

Query Monitor is private by default and always will be. It does not persistently store any of the data that it collects. It does not send data to any third party, nor does it include any third party resources. [Query Monitor's full privacy statement can be found here](https://querymonitor.com/privacy/).

### Accessibility Statement

Query Monitor aims to be fully accessible to all of its users. [Query Monitor's full accessibility statement can be found here](https://querymonitor.com/accessibility/).

## Screenshots

1. Admin Toolbar Menu
2. Aggregate Database Queries by Component
3. Database Queries
4. Timeline
5. Hooks and Actions
6. HTTP API Requests
7. Logs

## Frequently Asked Questions

### Does this plugin work with PHP 8?

Yes, it's actively tested and working up to PHP 8.5.

### Who can see Query Monitor's output?

By default, Query Monitor's output is only shown to Administrators on single-site installations, and Super Admins on Multisite installations.

In addition to this, you can set an authentication cookie which allows you to view Query Monitor output when you're not logged in, or when you're logged in as a user who cannot usually see Query Monitor's output. See the Settings panel for details.

### Does Query Monitor itself impact the page generation time or memory usage?

Short answer: Yes, but only a little.

Long answer: Query Monitor has a small impact on page generation time because it hooks into a few places in WordPress in the same way that other plugins do. The impact is negligible.

On pages that have an especially high number of database queries (in the hundreds), Query Monitor currently uses more memory than I would like it to. This is due to the amount of data that is captured in the stack trace for each query. I have been and will be working to continually reduce this.

### Can I prevent Query Monitor from collecting data during long-running requests?

Yes, you can call `do_action( 'qm/cease' )` to instruct Query Monitor to cease operating for the remainder of the page generation. It will detach itself from further data collection, discard any data it's collected so far, and skip the output of its information.

This is useful for long-running operations that perform a very high number of database queries, consume a lot of memory, or otherwise are of no concern to Query Monitor, for example:

* Backing up or restoring your site
* Importing or exporting a large amount of data
* Running security scans

### Are there any add-on plugins for Query Monitor?

[A list of add-on plugins for Query Monitor can be found here.](https://querymonitor.com/help/add-on-plugins/)

In addition, Query Monitor transparently supports add-ons for the Debug Bar plugin. If you have any Debug Bar add-ons installed, deactivate Debug Bar and the add-ons will show up in Query Monitor's menu.

### Where can I suggest a new feature or report a bug?

Please use [the issue tracker on Query Monitor's GitHub repo](https://github.com/johnbillion/query-monitor/issues) as it's easier to keep track of issues there, rather than on the wordpress.org support forums.

### Is Query Monitor already included with my hosting?

Some web hosts bundle Query Monitor as part of their hosting platform, which means you don't need to install it yourself. Here are some that I'm aware of:

* [Altis Cloud](https://www.altis-dxp.com/resources/developer-docs/dev-tools/).
* [WordPress VIP](https://wpvip.com/), although users need to be granted the `view_query_monitor` capability even if they're an Administrator. [See the WordPress VIP documentation for details](https://docs.wpvip.com/performance/query-monitor/enable/).

### Can I click on stack traces to open the file in my editor?

Yes. You can enable this on the Settings panel.

### How can I report a security bug?

You can submit a private security vulnerability report to Query Monitor via [the Security tab on the GitHub repo](https://github.com/johnbillion/query-monitor/security). The GitHub Security Advisory process facilitates private collaboration on security issues. You'll receive credit for a valid report and a CVE if necessary.

Do not report security issues on the WordPress.org support forums or via email. Thank you.

### Do you accept donations?

[I am accepting sponsorships via the GitHub Sponsors program](https://github.com/sponsors/johnbillion). If you work at an agency that develops with WordPress, ask your company to provide sponsorship in order to invest in its supply chain. The tools that I maintain probably save your company time and money, and GitHub sponsorship can now be done at the organisation level.

In addition, if you like the plugin then I'd love for you to [leave a review](https://wordpress.org/support/view/plugin-reviews/query-monitor). Tell all your friends about it too!
## Changelog ##

### 4.0.7 (20 June 2026) ###

- Confirms support for WordPress 7.0
- Makes improvements to the admin bar menu
- Shows database queries on the timeline even when db.php isn't in place
- Adds more error highlighting for problems with enqueued JavaScript and CSS dependencies
- Adds some back-compat for old versions of the Chrome browser

### 4.0.6 (11 April 2026) ###

Version 4 of Query Monitor adds a new timeline view, and switches from rendering its panels server-side in PHP to efficiently rendering them client-side in Preact.

Version 4.0.6 fixes a compatibility issue with the GeneratePress theme.

[More information at querymonitor.com/4](https://querymonitor.com/4).

### 4.0.5 (10 April 2026) ###

Version 4 of Query Monitor adds a new timeline view, and switches from rendering its panels server-side in PHP to efficiently rendering them client-side in Preact.

Version 4.0.5 fixes the following:

- Ensures closing script tags within data don't break the output
- Adds "Doing it Wrong" data to the timeline view

[More information at querymonitor.com/4](https://querymonitor.com/4).

### 4.0.4 (10 April 2026) ###

Version 4 of Query Monitor adds a new timeline view, and switches from rendering its panels server-side in PHP to efficiently rendering them client-side in Preact.

Version 4.0.4 fixes the following:

- Ensures the Scripts panel remains visible when no scripts are enqueued in the header
- Corrects the display of number formatting in some locales

[More information at querymonitor.com/4](https://querymonitor.com/4).

### 4.0.3 (9 April 2026) ###

Version 4 of Query Monitor adds a new timeline view, and switches from rendering its panels server-side in PHP to efficiently rendering them client-side in Preact.

Version 4.0.3 fixes the following:

- Improves compatibility with plugins that perform non-UTF8 queries or make other use of non-UTF8 data
- Avoids a PHP warning for undefined file and line number in some stack trace frames
- Simplifies and standardises the format of names used for closure callbacks
- Improves styling and layout of the timeline view

[More information at querymonitor.com/4](https://querymonitor.com/4).

### 4.0.2 (9 April 2026) ###

Version 4 of Query Monitor adds a new timeline view, and switches from rendering its panels server-side in PHP to efficiently rendering them client-side in Preact.

Version 4.0.2 fixes the following:

- Adds further backwards compatibility for third-party plugins that read from the QM data collectors and output their own panels
- Adds transient updates to the timeline view

[More information at querymonitor.com/4](https://querymonitor.com/4).

### 4.0.1 (7 April 2026) ###

Version 4 of Query Monitor adds a new timeline view, and switches from rendering its panels server-side in PHP to efficiently rendering them client-side in Preact.

- Version 4.0.1 fixes a backwards compatibility issue with plugins that register their own menus or sub-menus in Query Monitor.

[More information at querymonitor.com/4](https://querymonitor.com/4).

### 4.0.0 (7 April 2026) ###

Version 4 of Query Monitor adds a new timeline view, and switches from rendering its panels server-side in PHP to efficiently rendering them client-side in Preact. This new approach provides several benefits:

- Performance is greatly increased, particularly on sites where a large number of queries are performed, a large number of PHP errors are triggered, or a large amount of data is collected in one of the other panels.
- Further future enhancements are facilitated, such as displaying client-side metrics, lazy-loading data, showing data from different requests, and more remixing of data into different views.
- The raw data collected by Query Monitor has been reduced in size and memory usage, and is now exposed to the page as JSON. Take a look at the `QueryMonitorData` object in your browser console to play around with it.

[More information at querymonitor.com/4](https://querymonitor.com/4).

### 3.20.4 (19 March 2026) ###

* This is a security release which fixes a reflected XSS vulnerability in the Request panel. [Full details in the security advisory](https://github.com/johnbillion/query-monitor/security/advisories/GHSA-2xr4-chcf-vmvf).

### 3.20.3 (17 March 2026) ###

- Clicking QM in the the admin toolbar a second time will now close the panel
- Improvements to accessibility of the toggle buttons
- Failed HTTP API GET requests now show a clickable link


### Earlier versions ###

For the changelog of earlier versions, <a href="https://github.com/johnbillion/query-monitor/releases">refer to the releases page on GitHub</a>.
