<?php
/**
 * @package Polylang
 */

/**
 * Adds the language column in posts and terms list tables.
 * Manages quick edit and bulk edit as well.
 *
 * @since 1.2
 */
class PLL_Admin_Filters_Columns {
	/**
	 * @var PLL_Model
	 */
	public $model;

	/**
	 * This class is instantiated on `wp_loaded` (prio 5), see `PLL_Admin::add_filters()`.
	 * `$polylang->links` is instantiated on `wp_loaded` (prio 1), see `PLL_Admin_Base::init()`.
	 * This means `$polylang->links` cannot be `null`.
	 *
	 * @var PLL_Admin_Links
	 */
	public $links;

	/**
	 * Language selected in the admin language filter.
	 *
	 * @var PLL_Language|null
	 */
	public $filter_lang;

	/**
	 * Constructor: setups filters and actions.
	 *
	 * @since 1.2
	 *
	 * @param object $polylang The Polylang object.
	 */
	public function __construct( &$polylang ) {
		$this->links = &$polylang->links;
		$this->model = &$polylang->model;
		$this->filter_lang = &$polylang->filter_lang;

		// Hide the column of the filtered language.
		add_filter( 'hidden_columns', array( $this, 'hidden_columns' ) ); // Since WP 4.4.

		// Add the language and translations columns in 'All Posts', 'All Pages' and 'Media library' panels.
		foreach ( $this->model->get_translated_post_types() as $type ) {
			// Use the latest filter late as some plugins purely overwrite what's done by others :(
			// Specific case for media.
			add_filter( 'manage_' . ( 'attachment' == $type ? 'upload' : 'edit-' . $type ) . '_columns', array( $this, 'add_post_column' ), 100 );
			add_action( 'manage_' . ( 'attachment' == $type ? 'media' : $type . '_posts' ) . '_custom_column', array( $this, 'post_column' ), 10, 2 );
		}

		// Quick edit and bulk edit.
		add_filter( 'quick_edit_custom_box', array( $this, 'quick_edit_custom_box' ) );
		add_filter( 'bulk_edit_custom_box', array( $this, 'quick_edit_custom_box' ) );

		// Adds the language column in the 'Categories' and 'Post Tags' tables.
		foreach ( $this->model->get_translated_taxonomies() as $tax ) {
			add_filter( 'manage_edit-' . $tax . '_columns', array( $this, 'add_term_column' ) );
			add_filter( 'manage_' . $tax . '_custom_column', array( $this, 'term_column' ), 10, 3 );
		}

		// Ajax responses to update list table rows.
		add_action( 'wp_ajax_pll_update_post_rows', array( $this, 'ajax_update_post_rows' ) );
		add_action( 'wp_ajax_pll_update_term_rows', array( $this, 'ajax_update_term_rows' ) );
	}

	/**
	 * Adds languages and translations columns in posts, pages, media, categories and tags tables.
	 *
	 * @since 0.8.2
	 *
	 * @param string[] $columns List of table columns.
	 * @param string   $before  The column before which we want to add our languages.
	 * @return string[] Modified list of columns.
	 */
	protected function add_column( array $columns, string $before ): array {
		if ( $n = array_search( $before, array_keys( $columns ) ) ) {
			$end = array_slice( $columns, $n );
			$columns = array_slice( $columns, 0, $n );
		}

		foreach ( $this->model->get_languages_list() as $language ) {
			$columns[ 'language_' . $language->slug ] = $this->links->get_flag_html( $language ) . '<span class="screen-reader-text">' . esc_html( $language->name ) . '</span>';
		}

		return isset( $end ) ? array_merge( $columns, $end ) : $columns;
	}

	/**
	 * Returns the first language column in posts, pages, media, categories and tags tables.
	 *
	 * @since 0.9
	 *
	 * @return string First language column name.
	 */
	protected function get_first_language_column(): string {
		$languages = $this->model->get_languages_list();
		$language  = reset( $languages );
		return ! empty( $language ) ? "language_{$language->slug}" : '';
	}

	/**
	 * Hides the column for the filtered language.
	 *
	 * @since 2.7
	 *
	 * @param string[] $hidden Array of hidden columns.
	 * @return string[]
	 */
	public function hidden_columns( $hidden ) {
		if ( ! empty( $this->filter_lang ) ) {
			$hidden[] = 'language_' . $this->filter_lang->slug;
		}
		return $hidden;
	}

	/**
	 * Adds the language and translations columns ( before the comments column ) in the posts, pages and media library tables.
	 *
	 * @since 0.1
	 *
	 * @param string[] $columns List of posts table columns.
	 * @return string[] Modified list of columns.
	 */
	public function add_post_column( $columns ) {
		return $this->add_column( (array) $columns, 'comments' );
	}

	/**
	 * Fills the language and translations columns in the posts, pages and media library tables
	 * take care that when doing ajax inline edit, the post may not be updated in database yet.
	 *
	 * @since 0.1
	 *
	 * @param string $column  Column name.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public function post_column( $column, $post_id ): void {
		if ( ! str_starts_with( $column, 'language_' ) ) {
			return;
		}

		$post = get_post( (int) $post_id );

		if ( ! $post instanceof WP_Post ) {
			// Should not happen.
			return;
		}

		$inline = isset( $_POST['inline_lang_choice'], $_REQUEST['_inline_edit'] ) && is_string( $_REQUEST['_inline_edit'] ) && wp_verify_nonce( $_REQUEST['_inline_edit'], 'inlineeditnonce' );
		$lang   = $inline ? $this->model->get_language( sanitize_key( $_POST['inline_lang_choice'] ) ) : $this->model->post->get_language( $post->ID );

		if ( empty( $lang ) ) {
			return;
		}

		$language = $this->model->get_language( substr( $column, 9 ) );

		if ( empty( $language ) ) {
			return;
		}

		// Hidden field containing the post language for quick edit.
		if ( $column === $this->get_first_language_column() ) {
			printf( '<div class="hidden" id="lang_%d">%s</div>', (int) $post->ID, esc_html( $lang->slug ) );
		}

		$tr_id   = $this->model->post->get( $post->ID, $language );
		$tr_post = $tr_id ? get_post( $tr_id ) : null;

		if ( ! $tr_post instanceof WP_Post ) {
			// Link to add a new translation: no translation for this language yet, or it doesn't exist anymore.
			echo $this->links->get_new_post_link_html( $post, $language ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		// Link to edit (or not) the post or a translation.
		echo $this->links->get_edit_post_link_html( $tr_post, $tr_post->ID === $post->ID ? 'list_current' : 'list_translation' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Quick edit & bulk edit.
	 *
	 * @since 0.9
	 *
	 * @param string $column Column name.
	 * @return string Unmodified column.
	 */
	public function quick_edit_custom_box( $column ) {
		if ( $column !== $this->get_first_language_column() ) {
			return $column;
		}

		$elements = $this->model->languages->filter( 'translator' )->get_list();
		if ( current_filter() == 'bulk_edit_custom_box' ) {
			array_unshift( $elements, (object) array( 'slug' => -1, 'name' => __( '&mdash; No Change &mdash;', 'polylang' ) ) );
		}

		$dropdown = new PLL_Walker_Dropdown();
		printf(
			'<fieldset class="inline-edit-col-left">
				<div class="inline-edit-col">
					<label class="alignleft">
						<span class="title">%s</span>
						%s
					</label>
				</div>
			</fieldset>',
			esc_html__( 'Language', 'polylang' ),
			$dropdown->walk( $elements, -1, array( 'name' => 'inline_lang_choice', 'id' => '' ) ) // phpcs:ignore WordPress.Security.EscapeOutput
		);

		return $column;
	}

	/**
	 * Adds the language column (before the posts column) in the 'Categories' or 'Post Tags' table.
	 *
	 * @since 0.1
	 *
	 * @param string[] $columns List of terms table columns.
	 * @return string[] modified List of columns.
	 */
	public function add_term_column( $columns ) {
		$screen = get_current_screen();

		// Avoid displaying languages in screen options when editing a term.
		if ( $screen instanceof WP_Screen && 'term' === $screen->base ) {
			return $columns;
		}

		return $this->add_column( (array) $columns, 'posts' );
	}

	/**
	 * Fills the language column in the taxonomy terms list table.
	 *
	 * @since 0.1
	 *
	 * @param string $out     Column output.
	 * @param string $column  Column name.
	 * @param int    $term_id Term ID.
	 * @return string
	 */
	public function term_column( $out, $column, $term_id ) {
		if ( ! str_starts_with( $column, 'language_' ) ) {
			return $out;
		}

		$term_id = (int) $term_id;
		$inline  = isset( $_POST['inline_lang_choice'], $_REQUEST['_inline_edit'] ) && is_string( $_REQUEST['_inline_edit'] ) && wp_verify_nonce( $_REQUEST['_inline_edit'], 'taxinlineeditnonce' );
		$lang    = $inline ? $this->model->get_language( sanitize_key( $_POST['inline_lang_choice'] ) ) : $this->model->term->get_language( $term_id );

		if ( empty( $lang ) ) {
			return $out;
		}

		if ( isset( $GLOBALS['post_type'] ) ) {
			$post_type = $GLOBALS['post_type'];
		} elseif ( isset( $_REQUEST['post_type'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$post_type = sanitize_key( $_REQUEST['post_type'] ); // phpcs:ignore WordPress.Security.NonceVerification
		}

		if ( isset( $GLOBALS['taxonomy'] ) ) {
			$taxonomy = $GLOBALS['taxonomy'];
		} elseif ( isset( $_REQUEST['taxonomy'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$taxonomy = sanitize_key( $_REQUEST['taxonomy'] ); // phpcs:ignore WordPress.Security.NonceVerification
		}

		if ( ! isset( $taxonomy, $post_type ) || ! is_string( $post_type ) || ! is_string( $taxonomy ) || ! post_type_exists( $post_type ) || ! taxonomy_exists( $taxonomy ) ) {
			return $out;
		}

		$language = $this->model->get_language( substr( $column, 9 ) );

		if ( empty( $language ) ) {
			return $out;
		}

		$term = get_term( $term_id, $taxonomy );

		if ( ! $term instanceof WP_Term ) {
			// Should not happen.
			return $out;
		}

		$tr_id   = $this->model->term->get( $term->term_id, $language );
		$tr_term = $tr_id ? get_term( $tr_id, $taxonomy ) : null;

		if ( ! $tr_term instanceof WP_Term ) {
			// Link to add a new translation: no translation for this language yet, or it doesn't exist anymore.
			$out .= $this->links->get_new_term_link_html( $term, $post_type, $language );
		} else {
			// Link to edit (or not) the term or a translation.
			$out .= $this->links->get_edit_term_link_html( $tr_term, $post_type, $tr_term->term_id === $term->term_id ? 'list_current' : 'list_translation' );
		}

		if ( $this->get_first_language_column() === $column ) {
			// Hidden field containing the term language for quick edit.
			$out .= sprintf( '<div class="hidden" id="lang_%d">%s</div>', $term->term_id, esc_html( $lang->slug ) );

			/**
			 * Filters the output of the first language column in the terms list table.
			 *
			 * @since 3.7
			 *
			 * @param string $output  First language column output.
			 * @param int    $term_id Term ID.
			 * @param string $lang    Language code.
			 */
			$out = apply_filters( 'pll_first_language_term_column', $out, $term->term_id, $lang->slug );
		}

		return $out;
	}

	/**
	 * Update rows of translated posts when the language is modified in quick edit.
	 *
	 * @since 1.7
	 *
	 * @return void
	 *
	 * @phpstan-return never
	 */
	public function ajax_update_post_rows(): void {
		check_ajax_referer( 'inlineeditnonce', '_pll_nonce' );

		if ( ! isset( $_POST['post_type'], $_POST['post_id'], $_POST['screen'] ) ) {
			wp_die( 0 );
		}

		if ( ! is_numeric( $_POST['post_id'] ) ) {
			wp_die( 0 );
		}

		$post_type_object = get_post_type_object( sanitize_key( $_POST['post_type'] ) );

		if ( empty( $post_type_object ) || ! $this->model->is_translated_post_type( $post_type_object->name ) ) {
			wp_die( 0 );
		}

		$wp_list_table = _get_list_table( 'WP_Posts_List_Table', array( 'screen' => sanitize_key( $_POST['screen'] ) ) );

		if ( empty( $wp_list_table ) ) {
			wp_die( 0 );
		}

		$response = new WP_Ajax_Response();

		// Collect old translations.
		if ( ! empty( $_POST['translations'] ) && is_string( $_POST['translations'] ) ) {
			$translations = explode( ',', $_POST['translations'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$translations = array_filter( $translations, 'is_numeric' );
			$translations = array_map( 'intval', $translations );
			$translations = array_filter( $translations );
		} else {
			$translations = array();
		}

		$translations = array_merge( $translations, $this->model->post->get_translations( (int) $_POST['post_id'] ) );
		$translations = array_unique( $translations );

		if ( empty( $translations ) ) { // May occur if the modified post has no language.
			$response->send();
		}

		/** @var WP_Post[] */
		$posts = ( new WP_Query() )->query(
			array(
				// Do not add `post_status`, as this allows `WP_Query` to handle user capabilities to read private posts.
				'post__in'       => $translations,
				'post_type'      => $post_type_object->name,
				'posts_per_page' => count( $translations ),
				'no_found_rows'  => true,
				'orderby'        => 'ID',
				'lang'           => '',
			)
		);

		foreach ( $posts as $post ) {
			if ( $post_type_object->hierarchical ) {
				$level = count( get_ancestors( $post->ID, $post->post_type, 'post_type' ) );
			} else {
				$level = 0;
			}

			ob_start();
			$wp_list_table->single_row( $post, $level );
			$data = (string) ob_get_clean();

			$response->add(
				array(
					'what'         => 'row',
					'data'         => $data,
					'supplemental' => array( 'post_id' => $post->ID ),
				)
			);
		}

		$response->send();
	}

	/**
	 * Update rows of translated terms when adding / deleting a translation
	 * or when the language is modified in quick edit.
	 *
	 * @since 1.7
	 *
	 * @return void
	 *
	 * @phpstan-return never
	 */
	public function ajax_update_term_rows(): void {
		check_ajax_referer( 'pll_language', '_pll_nonce' );

		if ( ! isset( $_POST['taxonomy'], $_POST['term_id'], $_POST['screen'] ) ) {
			wp_die( 0 );
		}

		if ( ! is_numeric( $_POST['term_id'] ) ) {
			wp_die( 0 );
		}

		$taxonomy_object = get_taxonomy( sanitize_key( $_POST['taxonomy'] ) );

		if ( empty( $taxonomy_object ) || ! $this->model->is_translated_taxonomy( $taxonomy_object->name ) ) {
			wp_die( 0 );
		}

		$wp_list_table = _get_list_table( 'WP_Terms_List_Table', array( 'screen' => sanitize_key( $_POST['screen'] ) ) );

		if ( empty( $wp_list_table ) ) {
			wp_die( 0 );
		}

		$response = new WP_Ajax_Response();

		// Collect old translations.
		if ( ! empty( $_POST['translations'] ) && is_string( $_POST['translations'] ) ) {
			$translations = explode( ',', $_POST['translations'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$translations = array_filter( $translations, 'is_numeric' );
			$translations = array_map( 'intval', $translations );
			$translations = array_filter( $translations );
		} else {
			$translations = array();
		}

		$translations = array_merge( $translations, $this->model->term->get_translations( (int) $_POST['term_id'] ) );
		$translations = array_unique( $translations );

		if ( empty( $translations ) ) { // May occur if the modfied term has no language.
			$response->send();
		}

		/** @var WP_Term[] */
		$terms = ( new WP_Term_Query() )->query(
			array(
				'include'    => $translations,
				'taxonomy'   => $taxonomy_object->name,
				'hide_empty' => false,
				'orderby'   => 'term_id',
				'lang'       => '',
			)
		);

		foreach ( $terms as $term ) {
			if ( $taxonomy_object->hierarchical ) {
				$level = count( get_ancestors( $term->term_id, $taxonomy_object->name, 'taxonomy' ) );
			} else {
				$level = 0;
			}

			ob_start();
			$wp_list_table->single_row( $term, $level );
			$data = (string) ob_get_clean();

			$response->add(
				array(
					'what'         => 'row',
					'data'         => $data,
					'supplemental' => array( 'term_id' => $term->term_id ),
				)
			);
		}

		$response->send();
	}
}
