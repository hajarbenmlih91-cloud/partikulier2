# Pack Partikulier — 20 prompts senior

**Version :** 1.0  
**Périmètre :** CDC v3 consolidé  
**Contenu :** 10 prompts d’audit et 10 prompts de simulation  
**Objectif :** permettre à un développeur de reprendre les contrôles sans demander le contexte déjà établi.

## Utilisation

Exécuter chaque prompt dans un environnement disposable ou dans la CI prévue. Ne jamais utiliser la production. Le staging Hostinger reste hors périmètre tant qu’un accès légitime n’est pas rétabli et qu’une autorisation explicite n’est pas donnée. Ne jamais demander ni inclure de mot de passe, cookie, token, fichier `wp-config.php`, dump SQL ou secret.

Chaque exécution doit produire un artefact avec le SHA exact, la branche, l’environnement, la date UTC, la commande, la cible, la mesure, l’exit code et le chemin de preuve. Un résultat local ne doit pas être présenté comme une preuve staging. Un résultat sur un SHA parent ne qualifie pas un SHA enfant.

## Exit codes

| Code | Statut | Règle |
|---:|---|---|
| 0 | PASS | Cible atteinte et preuve complète |
| 1 | FAIL | Test exécuté mais cible non atteinte |
| 2 | INVALID | Test incomplet, non comparable ou contrat incohérent |
| 75 | BLOCKED | Dépendance d’environnement externe indisponible |
| 77 | NOT AUTHORIZED | Autorisation, décision produit ou relecteur manquant |

Tout résultat différent de `0` maintient le **NO-GO**. Aucun prompt ne peut transformer un blocage en PASS.

## Règles spécifiques

Les quatre échecs pixel actuellement observés sur `e488b12` sont `archive-ar-desktop`, `archive-ar-mobile`, `single-ar-desktop` et `single-ar-mobile`. Toute correction visuelle doit être précédée d’une reproduction et d’une cause attribuée; il est interdit de modifier une baseline pour faire passer le test.

La fixture synthétique propriété `249` et le média `250` restent publiés jusqu’à une autorisation écrite de suppression. Les objectifs d’import de 800 annonces, de trafic et de langues doivent être confirmés par une décision produit avant une exécution réelle.

## Ordre recommandé

Commencer par les audits A1 à A10 pour établir les faits. Exécuter ensuite les simulations S1 à S10 dans un runtime neuf. Corriger uniquement les défauts dont la cause est prouvée. Refaire les contrôles touchés par un nouveau commit, puis produire un tableau final sans mélanger les SHAs.

## Références

[1]: https://github.com/hajarbenmlih91-cloud/partikulier2 "Dépôt public Partikulier"
[2]: https://github.com/hajarbenmlih91-cloud/partikulier2/actions "Exécutions CI Partikulier"
