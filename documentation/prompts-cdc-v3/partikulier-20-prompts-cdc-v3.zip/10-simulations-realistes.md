# 10 prompts de simulation réaliste

## SIM-01 — Recherche et filtre cumulatif

> Dans un navigateur neuf, simule un visiteur qui ouvre `/fr/annonces/`, choisit une ville, un type de bien, un budget minimum et maximum, puis valide. Vérifie que les filtres restent cumulés, que l’URL est correcte, que le résultat correspond réellement aux critères, que le nombre de résultats est cohérent et que la page ne redirige pas prématurément. Répète en FR, EN et AR si ces langues sont autorisées. Capture les étapes, les URLs, le DOM pertinent, les réponses HTTP et l’artefact de résultat.

## SIM-02 — Filtres mobiles dans le bon ordre

> Sur viewport mobile 320, 360, 375 et 390 px, simule l’ouverture de la page annonces. Vérifie que le bouton de recherche et le bouton filtres sont accessibles avant la première annonce, que le panneau s’ouvre sans débordement, que le clavier et Escape fonctionnent, que les villes populaires apparaissent au bon emplacement et qu’aucune barre sticky indésirable ne masque le contenu. Vérifie aussi le retour à la liste après application et réinitialisation. Toute anomalie doit être capturée sans modifier le CSS pendant la simulation.

## SIM-03 — Autocomplete ville et recherche

> Simule un utilisateur qui tape une lettre puis plusieurs lettres dans la recherche principale et dans le filtre ville. Vérifie que les suggestions apparaissent, sont pertinentes, localisées et accessibles au clavier; vérifie ArrowDown, Enter, Escape, clic extérieur et texte sans résultat. Contrôle qu’aucune requête n’est déclenchée pour chaque frappe sans debounce mesuré et que l’URL finale ne contient pas de paramètre non autorisé. Exécute le scénario dans Chromium, Firefox et WebKit, puis fournis les logs et mesures.

## SIM-04 — Parcours d’une annonce et galerie

> Ouvre une annonce FR, EN puis AR depuis une archive. Vérifie URL, titre, ville, prix, badge vente/location, galerie, miniature, image principale, alt, JSON-LD, liens de partage et bouton favori. Répète le même scénario trois fois après rechargement et compare les hashes de la galerie. Si une capture varie, classe le résultat FAIL/INVALID et recherche d’abord la cause dans la fixture ou le runtime; ne rebaseline pas.

## SIM-05 — Dépôt d’annonce particulier

> Simule un particulier qui ouvre le dépôt depuis desktop puis mobile, choisit vente ou location, choisit un type de bien, renseigne ville, prix, surface, photos et caractéristiques adaptées au bien. Vérifie validation des champs, erreurs lisibles, nonce, contrôle de capacité, upload, absence de fuite d’information et état final. Ne soumets pas vers un service réel ni un webhook réel sans autorisation. Dans un environnement disposable, utilise des données synthétiques et journalise chaque étape.

## SIM-06 — Parcours immobilier spécialisé

> Simule successivement une villa, un appartement, un bureau et un terrain dans un environnement disposable. Vérifie que les champs conditionnels apparaissent seulement quand le type et l’action le justifient : piscine, sous-sol, jardin, chambres, salles de bains, ascenseur, concierge, chauffage, terrain agricole/industriel/urbain et options métier. Contrôle les libellés FR/EN/AR et les valeurs enregistrées. Ne crée aucune traduction ou donnée métier réelle sans décision produit explicite.

## SIM-07 — Contact propriétaire et sécurité

> Simule un visiteur qui ouvre une annonce puis tente de contacter le propriétaire avec un formulaire valide, un formulaire invalide, une session absente et une session expirée. Vérifie les nonces, capacités, validation serveur, échappements, anti-spam, logs sans secret et message utilisateur. Dans l’environnement disposable, remplace le canal externe par un faux récepteur local. Vérifie que le contact n’est ni perdu ni envoyé deux fois et mesure le temps de bout en bout.

## SIM-08 — Langues et RTL de bout en bout

> Exécute le même parcours recherche → annonce → dépôt → confirmation en FR, EN et AR. Vérifie langue de l’URL, titre, ville, prix, badges, textes d’erreur, JSON-LD, hreflang, `dir=rtl`, ordre de lecture, focus et absence de chaîne française non traduite dans l’interface arabe. Compare les captures desktop et mobile. Si une langue n’est pas autorisée par le produit, arrête le scénario avec exit `77` et documente la décision manquante.

## SIM-09 — Résilience, cache et retour arrière

> Simule deux visites anonymes consécutives d’une page publique, une visite avec cookie de session, une modification d’annonce, une suppression dans l’environnement disposable et une erreur d’origine simulée. Vérifie HIT/MISS, invalidation ciblée, absence de cache privé, contenu ancien servi selon la politique, retour HTTP, retry et absence de duplication. Recommence après redémarrage du runtime. Fournis headers, fichiers de cache, temps, état avant/après et règles exactes; n’utilise pas de purge réelle.

## SIM-10 — Parcours multi-navigateurs et charge utilisateur

> Exécute 10 parcours utilisateur représentatifs dans Chromium, Firefox et WebKit : accueil, annonces, filtres, autocomplete, annonce, favori, dépôt synthétique, contact simulé, changement de langue et retour arrière. Mesure succès, erreurs, console, requêtes bloquées, responsive aux largeurs contractuelles et durée par étape. Produis 30 exécutions distinctes et un tableau par navigateur/scénario. Toute exécution manquante vaut INVALID; un résultat local ne certifie pas le staging.
