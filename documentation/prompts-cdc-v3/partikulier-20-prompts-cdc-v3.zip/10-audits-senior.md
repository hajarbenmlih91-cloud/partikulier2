# 10 prompts d’audit senior

## AUDIT-01 — Sécurité PHP et WordPress

> Audite le dépôt Partikulier comme un responsable sécurité WordPress. Analyse PHP, JavaScript, hooks, REST, AJAX, formulaires, nonces, capacités, échappements, SQL, uploads, redirections, SSRF, XSS, CSRF, IDOR, secrets et dépendances. Pour chaque finding, donne le fichier, la ligne, la sévérité, la preuve reproductible, le risque, le correctif minimal et un test de non-régression. Sépare les vrais findings des faux positifs. Ne demande aucun secret. Termine par un tableau `PASS/FAIL/INVALID/BLOCKED/NOT AUTHORIZED` avec exit code et SHA exact.

## AUDIT-02 — Portée REST légère et équivalence métier

> Vérifie le MU-plugin REST léger et compare la réponse légère à la réponse normale sur tous les champs contractuels : vente, location, pagination, langue, ville, prix, images, URLs, JSON-LD et paramètres observés. Teste GET anonyme, utilisateur connecté, cookies, Authorization, POST/PUT/PATCH/DELETE, route hors listings et sous-routes. La portée doit être 10/10 et l’équivalence doit être 100 % ou justifiée champ par champ. Fournis JSON bruts, hashes normalisés, commandes, SHA, environnement et exit code. Une comparaison incomplète vaut `2` ou `75`, jamais PASS.

## AUDIT-03 — Cache de pages et invalidation

> Audite class-cache.php sans supposer que le cache fonctionne. Trace la décision pour GET/POST, utilisateur connecté, cookies de session, routes privées, filtres, pagination, langues et archives. Mesure deux requêtes consécutives sur `/fr/`, `/fr/annonces/`, une fiche et une archive paginée; relève les headers, le fichier produit, le temps et les raisons de bypass. Vérifie la clé, le TTL, la purge ciblée et la protection contre contenu privé. Propose uniquement un correctif démontré par une mesure avant/après et ajoute un test de régression. Ne fixe pas de taux HIT non mesuré.

## AUDIT-04 — Reproductibilité des fixtures et des baselines visuelles

> Analyse le seed, l’import média, l’ordre des IDs, les échecs d’import et le harnais de capture. Construis deux environnements froids identiques et compare `MEDIA_SHA`, DOM et captures. Répète chaque scénario sensible trois fois avec le même viewport, seed, médias et métadonnées. Localise toute différence et attribue sa cause aux données, au runtime, à l’asset ou au code. Interdis tout rebaseline silencieux. Produis `capture-variance.json`, les hashes et la décision PASS/FAIL/INVALID avec exit code.

## AUDIT-05 — Base de données, requêtes et plans d’exécution

> Cartographie les tables, méta-données, index, repositories et chemins de recherche réellement utilisés par le front et le REST. Mesure les tris prix/surface, filtres ville/type, pagination et statut sur des volumes reproductibles. Fournis `EXPLAIN`, temps, rows examined, filesort, temporary, nombre et coût des requêtes. Vérifie séparément toute copie de lecture comme `pk_listings`, ses opérations insert/update/delete, sa dérive et ses consommateurs. Ne recommande aucun index sans preuve de gain et sans vérifier les limites de longueur et de type des colonnes.

## AUDIT-06 — Capacity, saturation et profil de charge

> Exécute la capacity dans le runtime de référence CI à 4 CPU et distingue 10 RPS, write 2 RPS, burst, sessions concurrentes et sonde de saturation 50 RPS. Publie requests envoyées/livrées, HTTP errors, p50/p95/p99, CPU, mémoire et durée. Tout sous-test FAIL doit rendre le verdict global FAIL; aucune moyenne ne doit le masquer. Vérifie aussi que le script de gate lit réellement chaque sous-test. Ne baisse aucun seuil et ne remplace pas le runtime par php -S.

## AUDIT-07 — TTFB et attribution réseau

> Mesure au moins 20 fois chacune des routes home FR, archive FR, REST root et REST listings, depuis les sources autorisées. Sépare DNS, TCP, TLS, attente proxy, edge, upstream/origine, cache HIT/MISS et total. Compare les timestamps et headers disponibles sans attribuer une cause non observée. Si Hostinger ne fournit pas les logs, classe l’attribution BLOCKED ou NOT AUTHORIZED selon le cas. La cible p95 ≤ 800 ms ne passe que si les quatre routes la respectent avec preuves brutes.

## AUDIT-08 — Audit de lot et taxonomies

> Vérifie si le docteur du thème analyse une seule fiche ou tout le catalogue. Lance un audit de lot sur le volume de test autorisé et mesure les descriptions, alt, ville, action, prix, galerie, statut et traductions. Vérifie les termes à zéro annonce dans les taxonomies concernées. Donne les compteurs exacts, les IDs anonymisés si nécessaire, les règles appelées, la durée et l’artefact JSON. Une absence de lot ou une incohérence de données doit rester FAIL ou INVALID, sans créer de données réelles.

## AUDIT-09 — Internationalisation, RTL et accessibilité

> Audite FR/EN/AR sur les routes publiques et les parcours de dépôt, sans modifier les traductions. Vérifie URL, langue active, titre, ville, prix, badge, alt, JSON-LD, hreflang, `dir=rtl`, encodage, ordre de lecture, contraste, focus, clavier, labels et annonces d’erreur. Exécute les contrôles automatisés puis distingue clairement le résultat humain WCAG du résultat automatique. Chaque langue exigée doit être testée; une langue non autorisée vaut `77`, pas PASS.

## AUDIT-10 — Livraison, licences, CI et gouvernance

> Audite le diff depuis la base approuvée, la provenance SHA, le package thème pur, les fichiers de licence, le text domain, les baselines, les artefacts et les conditions de publication. Vérifie qu’aucun secret, dump, cookie ou configuration privée n’est livré. Compare package CI et rebuild détaché par SHA-256. Vérifie que le validateur reçoit effectivement `--results`, que le contrat et le tableau humain ont les mêmes IDs, et que les jobs conditionnels ne sont pas comptés comme PASS. Termine par un rapport de reprise sans déclarer GO si un gate est manquant.
