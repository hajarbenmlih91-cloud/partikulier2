# Installation Partikulier

Décompresser `theme/` dans `wp-content/themes/partikulier/` et `mu-plugins/` dans `wp-content/mu-plugins/`. Le mu-plugin est obligatoire : il protège la racine contre la redirection navigateur des robots avant le chargement du thème.
